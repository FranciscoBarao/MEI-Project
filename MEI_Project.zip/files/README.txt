
1. Compile the four sorting codes, for instance, in gcc:
  
   gcc quicksort.c -o quick

2. Run the python code to generate the input for the sorting code as follows:
 
   python gen.py

3. Run R code
    R < graphs.R --no-save





